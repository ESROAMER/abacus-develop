.. test_orb documentation master file, created by
   sphinx-quickstart on Fri Jun 11 16:54:33 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to ABACUS-module_basis/module_ao's documentation!
==============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   about
   ORB_api/library_root



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


