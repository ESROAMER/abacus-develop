#ifndef MYMATH_H
#define MYMATH_H

namespace ModuleBase
{
void heapsort(int n, double *r, int *ind);
void heapAjust(double r[], int ind[], int s, int m);//not be used now!
void hpsort(int n, double *ra, int *ind);
}

#endif // MYMATH_H


