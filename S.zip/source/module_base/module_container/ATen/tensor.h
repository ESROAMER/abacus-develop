#ifndef ATEN_TENSOR_H_
#define ATEN_TENSOR_H_

#include <ATen/core/tensor.h>

#endif // ATEN_TENSOR_H_