#ifndef CHECK_ATOMIC_STRU_H
#define CHECK_ATOMIC_STRU_H

#include "unitcell.h"

class Check_Atomic_Stru {
  public:
    static void check_atomic_stru(UnitCell& ucell, const double& factor);
};

#endif